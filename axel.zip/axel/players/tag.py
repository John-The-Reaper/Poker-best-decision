import numpy as np

class Tag():
    def __init__(self, stack): 
        self.stack = stack

        # Parameters - TAG : tight-aggressive équilibré
        self.multiplicator_min = 0.55
        self.multiplicator_max = 1.25
        self.behavior_level = 0.52
        self.aggressiveness = 10.0

    def multiplicator(self, win_chance):
        """Calcul le pourcentage de la stack que le joueur veut miser"""
        exponent_input = -self.aggressiveness * (win_chance - self.behavior_level)
        result = self.multiplicator_min + (self.multiplicator_max - self.multiplicator_min) / (1 + float(np.exp(exponent_input)))
        return float(round(result, 2))

    def action(self, amount_to_call, position, optimal_choice, optimal_bet_amount, win_chance):
        """TAG : joue tight et aggressive"""
        
        style_factor = self.multiplicator(win_chance)
        
        # Position awareness
        if position == "button":
            style_factor *= 1.18
        elif position == "cutt_off":
            style_factor *= 1.12
        elif position == "hijack":
            style_factor *= 1.06
        elif position == "utg":
            style_factor *= 0.88
        elif position == "small_blind":
            style_factor *= 0.92
        else:
            style_factor *= 0.95

        desired_total_bet_amount = optimal_bet_amount * style_factor
        desired_total_bet_amount = min(desired_total_bet_amount, self.stack)

        # CAS 1 : Pas de mise
        if amount_to_call == 0:
            if optimal_choice == "check":
                if win_chance < 0.35 and np.random.random() < 0.18:
                    bet_size = desired_total_bet_amount * 0.6
                    return {"bet": max(1, round(bet_size, 0))}
                return {"check": True}
            
            if desired_total_bet_amount < 0.05 * self.stack:
                return {"check": True}
            else:
                return {"bet": max(1, round(desired_total_bet_amount, 0))}

        # CAS 2 : Mise à payer
        else:
            if amount_to_call >= self.stack * 0.95:
                if optimal_choice == "fold" and win_chance < 0.35:
                    return {"fold": True}
                else:
                    return {"call": amount_to_call}
            
            if optimal_choice == "fold":
                if style_factor < 0.9 or win_chance < 0.35:
                    return {"fold": True}
                elif win_chance > 0.40 and np.random.random() < 0.15:
                    return {"call": amount_to_call}
                else:
                    return {"fold": True}
            
            elif desired_total_bet_amount <= amount_to_call:
                if optimal_choice == "fold" and win_chance < 0.38:
                    return {"fold": True}
                else:
                    return {"call": amount_to_call}
            
            else:
                if win_chance > 0.55 or (optimal_choice in ["bet", "raise"] and style_factor > 1.05):
                    total_raise_amount = desired_total_bet_amount
                    return {"raise": max(amount_to_call + 1, round(total_raise_amount, 0))}
                else:
                    return {"call": amount_to_call}