import numpy as np

class Calling_station():
    def __init__(self, stack): 
        self.stack = stack

        # Parameters - Calling station : passive et trop loose
        self.min_bet = 0.03
        self.max_bet = 0.12
        self.behavior_level = 0.35
        self.aggressiveness = 1.8
        
        # Seuils spécifiques
        self.fold_threshold = 0.22
        self.raise_threshold = 0.75

    def multiplicator(self, win_chance):
        """Calcul le pourcentage de la stack que le joueur veut miser"""
        exponent_input = -self.aggressiveness * (win_chance - self.behavior_level)
        result = self.min_bet + (self.max_bet - self.min_bet) / (1 + float(np.exp(exponent_input))) 
        return float(round(result, 2))
    
    def action(self, amount_to_call, position, optimal_choice, optimal_bet_amount, win_chance):
        """
        ⚠️ SIGNATURE CORRECTE : 5 paramètres obligatoires
        Calling station : call beaucoup trop souvent, fold rarement
        """
        
        # Facteur de position réduit
        position_factor = 1.0
        if position == "button":
            position_factor = 1.08
        elif position == "cutt_off":
            position_factor = 1.05
        elif position == "hijack":
            position_factor = 1.02
        elif position == "utg":
            position_factor = 0.95
        elif position == "small_blind":
            position_factor = 1.03
        else:
            position_factor = 1.00

        # ✅ UTILISE LA VRAIE WIN_CHANCE
        desired_total_bet_amount = (self.multiplicator(win_chance) * self.stack) * position_factor

        # CAS 1 : Pas de mise
        if amount_to_call == 0:
            if win_chance < 0.50:
                if np.random.random() < 0.85:
                    return {"check": True}
                else:
                    bet_size = desired_total_bet_amount * 0.6
                    return {"bet": max(1, round(bet_size, 0))}
            elif win_chance < 0.70:
                if np.random.random() < 0.60:
                    return {"check": True}
                else:
                    bet_size = desired_total_bet_amount * 0.8
                    return {"bet": max(1, round(bet_size, 0))}
            else:
                if np.random.random() < 0.25:
                    return {"check": True}
                else:
                    return {"bet": max(1, round(desired_total_bet_amount, 0))}

        # CAS 2 : Mise à payer
        else:
            # All-in forcé
            if amount_to_call >= self.stack * 0.95:
                if win_chance < 0.40:
                    return {"fold": True}
                else:
                    return {"call": amount_to_call}
            
            # Fold très rare
            if win_chance < self.fold_threshold:
                if np.random.random() < 0.30 and amount_to_call < self.stack * 0.15:
                    return {"call": amount_to_call}
                return {"fold": True}
            
            # Call trop souvent
            elif win_chance < 0.50:
                if amount_to_call > self.stack * 0.40:
                    if win_chance < 0.30:
                        return {"fold": True}
                    elif np.random.random() < 0.70:
                        return {"fold": True}
                return {"call": amount_to_call}
            
            elif win_chance < self.raise_threshold:
                if amount_to_call > self.stack * 0.60:
                    if win_chance < 0.55:
                        return {"fold": True}
                return {"call": amount_to_call}
            
            # Nuts → call principalement
            else:
                if np.random.random() < 0.75:
                    return {"call": amount_to_call}
                else:
                    total_raise_amount = min(self.stack, amount_to_call * 2.3)
                    return {"raise": max(amount_to_call + 1, round(total_raise_amount, 0))}