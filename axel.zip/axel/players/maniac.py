import numpy as np

class Maniac():
    def __init__(self, stack): 
        self.stack = stack

        # Parameters - Maniac : ultra-loose et ultra-aggressive
        self.multiplicator_min = 1.00
        self.multiplicator_max = 2.20
        self.behavior_level = 0.15
        self.aggressiveness = 6.0

    def multiplicator(self, win_chance):
        """Calcul le pourcentage de la stack que le joueur veut miser"""
        exponent_input = -self.aggressiveness * (win_chance - self.behavior_level)
        result = self.multiplicator_min + (self.multiplicator_max - self.multiplicator_min) / (1 + float(np.exp(exponent_input)))
        return float(round(result, 2))

    def action(self, amount_to_call, position, optimal_choice, optimal_bet_amount, win_chance):
        """Maniac : joue ultra-loose et ultra-aggressive"""
        
        style_factor = self.multiplicator(win_chance)
        
        if position == "button":
            style_factor *= 1.10
        elif position == "cutt_off":
            style_factor *= 1.08
        elif position == "hijack":
            style_factor *= 1.05
        elif position == "utg":
            style_factor *= 1.02
        elif position == "small_blind":
            style_factor *= 1.05
        else:
            style_factor *= 1.00

        desired_total_bet_amount = optimal_bet_amount * style_factor
        desired_total_bet_amount = min(desired_total_bet_amount, self.stack)

        # CAS 1 : Pas de mise
        if amount_to_call == 0:
            if win_chance < 0.20:
                if np.random.random() < 0.75:
                    bet_size = desired_total_bet_amount * 0.85
                    return {"bet": max(1, round(bet_size, 0))}
                else:
                    return {"check": True}
            else:
                if np.random.random() < 0.08:
                    return {"check": True}
                else:
                    bet_size = desired_total_bet_amount * 1.1
                    return {"bet": max(1, round(min(bet_size, self.stack), 0))}

        # CAS 2 : Mise à payer
        else:
            if amount_to_call >= self.stack * 0.95:
                if win_chance < 0.18:
                    if np.random.random() < 0.60:
                        return {"fold": True}
                    else:
                        return {"call": amount_to_call}
                else:
                    return {"call": amount_to_call}
            
            if win_chance < 0.15 and amount_to_call > self.stack * 0.50:
                return {"fold": True}
            elif win_chance < 0.25:
                if amount_to_call > self.stack * 0.40:
                    if np.random.random() < 0.70:
                        return {"fold": True}
                    else:
                        return {"call": amount_to_call}
                else:
                    if np.random.random() < 0.50:
                        total_raise_amount = desired_total_bet_amount * 1.2
                        total_raise_amount = min(total_raise_amount, self.stack)
                        return {"raise": max(amount_to_call + 1, round(total_raise_amount, 0))}
                    else:
                        return {"call": amount_to_call}
            else:
                if desired_total_bet_amount <= amount_to_call:
                    return {"call": amount_to_call}
                else:
                    total_raise_amount = desired_total_bet_amount * 1.15
                    total_raise_amount = min(total_raise_amount, self.stack)
                    return {"raise": max(amount_to_call + 1, round(total_raise_amount, 0))}