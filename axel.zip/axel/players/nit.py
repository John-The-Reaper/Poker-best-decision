import numpy as np

class Nit():
    def __init__(self, stack): 
        self.stack = stack

        # Parameters - Nit : ultra-tight
        self.multiplicator_min = 0.08
        self.multiplicator_max = 1.50
        self.behavior_level = 0.72
        self.aggressiveness = 8.0

    def multiplicator(self, win_chance):
        """Calcul le pourcentage de la stack que le joueur veut miser"""
        exponent_input = -self.aggressiveness * (win_chance - self.behavior_level)
        result = self.multiplicator_min + (self.multiplicator_max - self.multiplicator_min) / (1 + float(np.exp(exponent_input)))
        return float(round(result, 2))

    def action(self, amount_to_call, position, optimal_choice, optimal_bet_amount, win_chance):
        """Nit : joue ultra-tight"""
        
        style_factor = self.multiplicator(win_chance)
        
        if position == "button":
            style_factor *= 1.08
        elif position == "cutt_off":
            style_factor *= 1.05
        elif position == "hijack":
            style_factor *= 1.02
        elif position == "utg":
            style_factor *= 0.95
        elif position == "small_blind":
            style_factor *= 0.90
        else:
            style_factor *= 0.92

        desired_total_bet_amount = optimal_bet_amount * style_factor
        desired_total_bet_amount = min(desired_total_bet_amount, self.stack)

        # CAS 1 : Pas de mise
        if amount_to_call == 0:
            if win_chance < 0.60:
                if np.random.random() < 0.95:
                    return {"check": True}
                else:
                    bet_size = desired_total_bet_amount * 0.5
                    return {"bet": max(1, round(bet_size, 0))}
            elif win_chance < 0.80:
                if np.random.random() < 0.60:
                    return {"check": True}
                else:
                    bet_size = desired_total_bet_amount * 0.9
                    return {"bet": max(1, round(bet_size, 0))}
            else:
                if np.random.random() < 0.15:
                    return {"check": True}
                else:
                    bet_size = desired_total_bet_amount * 1.1
                    return {"bet": max(1, round(min(bet_size, self.stack), 0))}

        # CAS 2 : Mise à payer
        else:
            if amount_to_call >= self.stack * 0.95:
                if win_chance < 0.70:
                    return {"fold": True}
                else:
                    return {"call": amount_to_call}
            
            if win_chance < 0.48:
                return {"fold": True}
            elif win_chance < 0.65:
                if amount_to_call > self.stack * 0.20:
                    if np.random.random() < 0.70:
                        return {"fold": True}
                return {"call": amount_to_call}
            elif win_chance < 0.80:
                if desired_total_bet_amount <= amount_to_call:
                    return {"call": amount_to_call}
                else:
                    if np.random.random() < 0.40:
                        return {"call": amount_to_call}
                    else:
                        total_raise_amount = desired_total_bet_amount
                        return {"raise": max(amount_to_call + 1, round(total_raise_amount, 0))}
            else:
                if desired_total_bet_amount <= amount_to_call:
                    return {"call": amount_to_call}
                else:
                    total_raise_amount = desired_total_bet_amount * 1.15
                    total_raise_amount = min(total_raise_amount, self.stack)
                    return {"raise": max(amount_to_call + 1, round(total_raise_amount, 0))}